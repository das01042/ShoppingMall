//document 1) createElements(tag) => tag 생성
//         2) getElementsByTagName(tage) = > 페이지 내 element선택
function createList() {
    var ul = document.createElement('ul');
    var li = document.createElement('li');
    li.textContent = 'banana';
    ul.appendChild(li);

    var li = document.createElement('li');
    li.textContent = 'cherry';
    
    ul.appendChild(li);

    var bd = document.getElementsByTagName('body');

    console.log(bd[0].appendChild(ul));
    //<body><ul><li>banana</li></ul></body>
}

var tbl = window.document.createElement('table'); //element<TAG> 생성.
tbl.setAttribute('border', '1');
tbl.setAttribute('id', 'tbl');
tbl.setAttribute('class','tbl');


/*{ <div class="container">
        <ul>
            <li>Apple</li>
            <li>Banana</li>
            <li>Cherry</li>
        </ul>
    </div>
    <script>
        var div = document.createElement('div');
        div.setAttribute('id','main');
        var ulTag = document.createElement('ul');
        var liTag = document.createElement('li');
        liTag.textContent = 'Apple';
        ulTag.appendChild(liTag); // <ul><li></li></ul>
        div.appendChild(ulTag); // <div><ul><li></li></ul></div>
        var bd =document.getElementsByTagName('body');
        bd[0].appendChild(div);
    </script> }*/
    // <input type="text" id="user_id" value =12345><br>
    // <button onclick ="getIdFunc()">id값 가져오기</button>
    // <button onclick="drawTable()">클릭</button>
    // <div id="show"></div>
    

   
    //     function getIdFunc(){
    //         var userId = document.getElementById('user_id');
    //         console.log(userId.value);
    //     }
    //     var students = [{
    //             name: "홍길동",
    //             math: 80,
    //             eng: 90,
    //             grade: "1학년 1반",
    //             avg: 85
    //         },
    //         {
    //             name: "김수미",
    //             math: 85,
    //             eng: 85,
    //             grade: "1학년 2반",
    //             avg: 90
    //         }, {
    //             name: "김민수",
    //             math: 90,
    //             eng: 75,
    //             grade: "1학년 3반",
    //             age : 80
    //         }
    //     ];
        
    //     function drawTable() {
    //     var bd = document.getElementsByTagName('body');
    //     var div = document.createElement('div');
    //     var table = document.createElement('table');
    //     table.setAttribute('border', '1');
    //     var tbody = document.createElement('tbody');
    //     var thead = document.createElement('thead');
    //     var th = document.createElement('th');





    //     div.appendChild(table);
    //     table.appendChild(tbody);

    //     var tr = document.createElement('tr');
    //     for (var val in students[0]) {
    //         var th = document.createElement('th');
    //         th.textContent = val;
    //         tr.appendChild(th);
    //     }
    //     thead.appendChild(tr);
    //     table.appendChild(thead);


    //     for (var student of students) {
    //         var tr = document.createElement('tr');

    //         for (var field in student) {
    //             var td = document.createElement('td');
    //             td.textContent = student[field];
    //             tr.appendChild(td);
    //         }
        
    //         tbody.appendChild(tr);
    //     }
    
    //     bd[0].appendChild(div);

    //     //화면 보여주기
    //     var disShow = document.getElementById('show');
    //     disShow[0].appendChild(table);
    // }
    //     var divShow_getIdFunc = document.getElementsByTagName('div');
    //         divShow_getIdFunc[0].appendChild(table);

    

