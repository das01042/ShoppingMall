//calendar.js
var year = 2021;
var month = 12; //월별 0~11로  인식하기 때문에 -1 추가


function createCalendar(year , month){
var thisMonth = new Date(year, month-1); //2021년 12월 1일
var thisMonthDay = thisMonth.getDay(); //1일의 요일정보 확인.
console.log(thisMonth.getDay()); //해당 날짜의 요일정보 : 0=> 일요일  1=> 월요일 ... 6=>토요일


var today = new Date();
console.log(today.getDate());
var todate = today.getDate();


var days = ["일", "월", "화", "수", "목", "금", "토"];
var str = "";
str += "<table border=`1`>";
str += "<caption>" + year+"년 "+month+"월" + "</caption>";
str += "<thead>";
for (var day of days) {
    str += "<th>" + day + "</th>";
}
str += "</thead>";
str += "</tbody>";
str += "<tr>";
for(var i=0;i<thisMonthDay; i++){
    str += "<td></td>";
}
var lastDay = getLastDate(year ,month);
for (var i = 1; i <= lastDay; i++) {
    if (i == todate) {
        str += "<td onclick ='clickFnc(event)'>" + i + "</td>";
    } else {
        str += "<td onclick ='clickFnc(event)'>" + i + "</td>";
    }
    if ((i +thisMonthDay) %7 == 0) {
        str += "</tr><tr>";
    }
}
str += "</tr></tbody></table>"

document.write(str);
} // end of createCalendar

function getLastDate(year ,month) {
    var result = -1;
    switch (month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            result = 31;
            break;
        case 2:
            result = getFebLeafYear(year) ? 29: 28;
            break;
        
        default :
            result = 30;
            break;
        
    }
    return result;
} //end of getLastDate

function getFebLeafYear(year){
    //년도 4로 나눠지면 윤년
    //100으로 나누어지면 평년
    //다시 400으로 나누어지면 윤년
    //윤년 - > true 아니면 false
    if(year%4==0){
        if(year%100==0){
            if(year%400==0){
                return true;
            }else if (year%400!=0){
                return false;
            }
        }else{
            return true;
        }
        return true;
    }else{
        return false;
    }
        

}

function clickFnc(e){
    console.log(this);
    console.log(e.target.textContent); // this ->window 객체
    window.alert(e.target.textContent + "를 선택했습니다"); //alert : 팝업알림창 띄움
    
}

//object는 값을 가지고 속성(필드 )
//object는 기능 가지고 메소드(메소드)

var obj ={
    name:"홍길동",
    age : 15,
    getInfo: function(){
        return " 이름은 " + this.name + ",나이는 "+this.age +"입니다."
    }
}

console.log(obj.getInfo());
