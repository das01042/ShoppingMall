var v1; //정적 변수가 아닌 동적 변수
        window.console.log(typeof v1); //undefined << 이것도 데이터타입

        v1 = 10; //number
        window.console.log(typeof v1); //number
        v1 = 'hello'; // String (자바 스크립트는 문자열을 '' 따옴표로 표시)
        window.console.log(typeof v1); // String
        v1 = true;
        window.console.log(typeof v1); // boolean
        v1 = null;
        window.console.log(typeof v1); //널값은 object 타입에 해당

        var result = 10 + 20; //숫자
        console.log(result);
        result = '10' + '20'; //문자열
        console.log(result);
        result = '20' / '10'; //문자열도 숫자로 인식해서 나눌수 있음
        console.log(result);
        var result = 30 * '2'; // 마찬가지
        console.log(result);

        var Result = 60; // 대소문자 구분을 한다
        if (result == Result) {
            console.log('같습니다')
        } else {
            console.log('같지 않습니다')
        }


        window.document.write('<h1>Hello</h1>'); //데이터값 출력기능
        //태그적용도 가능
        var strTag = '<h1> hello </h1>'; //누적 연산자
        strTag += '<ul><li>Apple<li>';
        strTag += '<li>Bananas<li>';
        strTag += '</ul>';
        window.document.write(strTag);

        strTag = "result 변수에 들어있는 값 " + result;
        window.document.write(strTag);
        strTag = `result 변수에 들어있는 값 ${result}<br>`;
        window.document.write(strTag);

        result = 6 / 4;
        document.write(result);

        if (result > 1) { //<br> 자바의 \ln이랑 같음 줄띄움
            document.write(`<br> 1보다 큽니다.<br>`);
        } else {
            document.write(`<br> 1보다 작습니다.<br>`);
        }

       
        for (var i = 1; i <= 10; i++) {
            document.write(` ${i} <br>`);
        }
        document.write(`<ul>`);

        var cnt = 10;
        while(cnt){
            document.write(`<li> i의 값 : ${cnt}</li>`);  //세미콜론 생략 가능
            cnt --;
        }
        document.write(`<ul>`);
        // false 값 : +0, -0, null, '', undefined
                    //(+0)과  0은 같지만  -0과 (0,+0)은 다름

                    // 11-19
        //object 타입
        var obj = {};// new object();
        obj.id = 'user1';
        obj.name = 'Hong';
        obj['phone'] = '010-1111-2222';
        console.log(obj);

        obj={
            id:'user2',
            name: 'Hwang',
            phone : '010-1111-1212'
        }
        var field = 'phone';
        console.log(typeof obj);
        
        document.write(`<p>id: ${obj.id}</p>`);
        document.write(`<p>name : ${obj['name']}</p>`);
        document.write(`<p>phone : ${obj[field]}</p>`);

        var ary = []; // new Array();
        ary[0] = 'Hong';
        ary[1] = 'Hwang';
        ary[2] = 'Park';
        ary[3] = 100;//자바에선 하나의 타입만 가능하지만 스크립트는 동적 변수가 
        ary[4]  = {name : 'Amy', age : 15};           //가능하기때문에 여러 타입을 하나의 배열로 쓸수 있음
                            
        delete ary[1];  //값을 지워도 배열의 칸은 남아있음(undefined 표시함)
        console.log(ary[0]);
        console.log('=====================================');
        for(var i=0; i<ary.length; i++){
            if(ary[i] != undefined){ //if문으로 undefined 칸은 삭제
            console.log(ary[i]);
            }
        }
        //primitive type.
        var a = b = 10;
        a= 20;

        console.log(a,b);

        //reference type.
        var obj1={
            name : 'Hwang'
        }

        var obj2 = obj1;
        obj2.name = 'Kim';

        console.log(obj1); // 오브젝트 타입도 다른 타입들과 특성이 비슷함
        var kim = {
            name: 'Kim',
            age: 25,
            phone: '010-1111'

        }
        var lee = {
            name: 'Lee',
            age: 28,
            phone: '010-2222'
        }
        var park = {
            name: ' Park',
            age: 33,
            phone: '010-3333'
        }
        //for(var ~  in ~)
        park.address = '대구 100번지';
        park['birth'] = '1995-05-05';
        for (var field in park) {
            console.log(field);
            console.log(field, park[field]);
            // object일 경우에 for.in 반복문.
            for(var field in park){
                console.log(field,park[field]);
            }
        }
        console.clear(); //보다 위에있는 콘솔 출력을 지움

        // for(var ~ of ~)
        var objAry = [kim, lee, park];
        document.write(`<table border="1">`);
        for (var obj of objAry) {
            // console.log(obj)  //obj는 전체   name이면 name만 부분적으로 가져올수 있음
            document.write(`<tr>`);
            for(var field in obj){
                // console.log(`${field},${obj[field]}`); //필드 이름(${field}) 과 값(${obj[field]})을 출력
                
                document.write(`<td>${obj[field]}</td>`);
                
            }
            document.write(`</tr>`);
            console.log('-----------------------------------')
        }
        document.write(`</table>`);