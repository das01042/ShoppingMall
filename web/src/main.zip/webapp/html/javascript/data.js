var data = `         
[{"id":1,"first_name":"Claudell","last_name":"Alans","email":"calans0@bigcartel.com","gender":"Male","salary":3931},
{"id":2,"first_name":"Danielle","last_name":"Colbertson","email":"dcolbertson1@theglobeandmail.com","gender":"Female","salary":7208},
{"id":3,"first_name":"Mortie","last_name":"Cresswell","email":"mcresswell2@51.la","gender":"Male","salary":4973},
{"id":4,"first_name":"Stirling","last_name":"Christoffe","email":"schristoffe3@cargocollective.com","gender":"Female","salary":11603},
{"id":5,"first_name":"Winifred","last_name":"Charnick","email":"wcharnick4@ocn.ne.jp","gender":"Male","salary":11015},
{"id":6,"first_name":"Kennett","last_name":"Sargent","email":"ksargent5@chronoengine.com","gender":"Male","salary":3889},
{"id":7,"first_name":"Gussy","last_name":"Jouandet","email":"gjouandet6@hubpages.com","gender":"Female","salary":6773},
{"id":8,"first_name":"Therese","last_name":"MacSporran","email":"tmacsporran7@businessweek.com","gender":"Female","salary":7246},
{"id":9,"first_name":"Jacquelyn","last_name":"Yuryaev","email":"jyuryaev8@redcross.org","gender":"Male","salary":9981},
{"id":10,"first_name":"Cal","last_name":"Levesley","email":"clevesley9@php.net","gender":"Female","salary":9533}]
`;
var dataAry = JSON.parse(data);