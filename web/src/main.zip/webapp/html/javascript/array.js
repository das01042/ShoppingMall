//2021-11-23 

//array.js

var checkedAry = [];

//sno,sname,sphone,sbirth =>students
var fields = {
    sno: '학번',
    sname: '이름',
    sphone: '연락처',
    sbirth: '생년월일'

};

var str = `
    <form action = 'basic.html' name='myname' id='myform' onsubmit='submitFnc(event)'>
        학번 : <input type ='text' name = 'sno'><br>
        이름 : <input type = 'text' name = 'sname'><br>
        연락처 : <input type = 'text' name = 'sphone'><br>
        생년월일 : <input type = 'text' name = 'sbirth'><br>
        <input type = 'submit' value = '저장'>
    </form>
    <form action = 'basic.html'name = 'secondName' id = 'secondForm'>

    <input type = 'text' name = 'id'>
    </form>
`;
document.write(str);
document.write('<div id = "show"></div>');
// document.getElementById('myform').onsubmit = function(){};

//저장버튼 클릭 => 입력값이 화면에 추가.
function submitFnc(e) {
    e.preventDefault();
    //preventDefault();  submitFnc의 기능을 차단
    // var s_sno = document.querySelector('form>input[name="sno"]').value;
    // var s_sname = document.querySelector('form>input[name="sname"]').value;
    // var s_sphone = document.querySelector('form>input[name="sphone"]').value;
    // var s_sbirth = document.querySelector('form>input[name="sbirth"]').value;

    console.log(document.forms['myform'].elements);
    console.log(document.forms['myform'].elements['sno'].value);  //.myform도 같은 사용 방법

    var s_no = document.forms['myform'].elements[0].value;
    var s_name = document.forms['myform'].elements[1].value;
    var s_phone = document.forms['myform'].elements[2].value;
    var s_birth = document.forms['myform'].elements[3].value;




    // console.log(s_sno, s_sname, s_sphone, s_sbirth);
    var std = {
        sno: s_no,
        sname: s_name,
        sphone: s_phone,
        sbirth: s_birth
    }

     document.getElementById('tby').appendChild(getTrStudent(std));

}
//데이터 추가
function getTrStudent(student) {
    //checkbox, td....,button

    var tr = document.createElement('tr');
    tr.onmouseover = mouseOverFnc;
    tr.onmouseout = mouseOutFnc;
    var td = document.createElement('td');
    var checkbox = document.createElement('input');
    checkbox.onchange = changeFnc;
    checkbox.setAttribute('type', 'checkbox');
    td.appendChild(checkbox);
    tr.appendChild(td);

    for (var field in fields) {
        td = document.createElement('td');
        td.textContent = student[field];
        tr.appendChild(td);
    }
    var td = document.createElement('td');
    var btn = document.createElement('button');
    btn.textContent = '복사';
    btn.onclick = clickFnc;
    td.appendChild(btn);
    tr.appendChild(td);




    return tr;
}


createTableList();

function createTableList() {
    var table = document.createElement('table');
    table.setAttribute('border', '1');
    //타이틀 부분 생성
    var thead = makeHead();
    table.appendChild(thead);

    //데이터 부분 생성
    var tbody = makeBody();
    table.appendChild(tbody);

    //div 하위 요소로 출력
    document.getElementById('show').appendChild(table);
}
//이벤트 속성 함수
function mouseOverFnc() {
    this.style.backgroundColor = 'yellow';
    event.target.parentNode;
}

function mouseOutFnc() { //this 이벤트일 경우 이벤트를 받는 대상
    this.style.backgroundColor = ''
}

function clickFnc(e) { //e라는 이벤트 매개변수를 받아옴
    // 1.줄 삭제
    // console.log(this); //this = > window를 가져옴
    // console.log(e.path[2].remove()); //.children[1] 으로 path[?]에 해당하는 하위 객체를 선택가능
    // console.log(e.path[0]); // .path[0] == ['path'][0] 사용 방법의 차이
    //.textContent=  로 수정 가능
    //..remove() 로 삭제 가능

    // 2-1. 복제 
    var no = this.parentNode.parentNode.children[1].textContent;
                    // td          tr
    var name = this.parentNode.parentNode.children[2].textContent;
    var phone = this.parentNode.parentNode.children[3].textContent;
    var birth = this.parentNode.parentNode.children[4].textContent;

    var obj = {
        sno:no,
        sname : name,
        sphone : phone,
        sbirth : birth
    }
    // document.getElementById('tby').appendChild(getTrStudent(obj));


    //2-2.복제 : 상태까지 같이 복사 
    // var selected_tr = this.parentNode.parentNode;
    // var clone_tr = selected_tr.cloneNode(true);
    // console.log(clone_tr);
    // document.getElementById('tby').appendChild(clone_tr);

    document.getElementById('tby').appendChild(getTrStudent(obj));
   
  

}

function changeFnc() { //nextSibling : 같은 종류의 다음 태그를 지목
    var searchSno = this.parentNode.nextSibling.nextSibling.textContent;
    // console.log(this.parentNode.nextSibling.textContent);
    if (this.checked == true) {
        var length = checkedAry.length;
        //checkedAry[length] = searchSno;
        checkedAry.splice(length, 0, searchSno);
    } else {
        for (var i = 0; i < checkedAry.length; i++) {
            if (checkedAry[i] == searchSno) {
                // delete checkedAry[i];
                checkedAry.splice(i, 1);
                //splice(i ,1);i위치에서 1개의 위치의 값을 지우겠다
                //splice(i ,1,'added'); i선택 1 삭제 'added'수정
                break;
            }
        }
    }
    console.log(checkedAry);
}
//데이터 부분
function makeBody() {
    var tbody = document.createElement('tbody');
    tbody.setAttribute('id', 'tby');
    for (var student of students) {
        //tbody.appendChild(getTrStudent(student)); //중복되는 코드 정리하고 주석제거
        var tr = document.createElement('tr');
        tr.onmouseover = mouseOverFnc; //function{
        //     //onmouseover : 마우스 커서를 올리면 실행
        //     console.log(this.style.backgroundColor = 'yellow'); //tr
        //     console.log(event.target.parentNode); 
        //                         //parentNode : 상위 요소를 불러옴
        // }
        tr.onmouseout = mouseOutFnc; //function(){
        //     console.log(this.style.backgroundColor = '');
        // }

        //추가 데이터 내용(체크박스)
        var td = document.createElement('td');
        var checkbox = document.createElement('input');
        checkbox.onchange = changeFnc;
        //onchange :
        checkbox.setAttribute('type', 'checkbox');
        // td.innerHTML = "<input type= 'checkbox'>";
        td.appendChild(checkbox);
        tr.appendChild(td);

        //원래 필드
        for (var field in fields) {
            td = document.createElement('td');
            td.textContent = student[field];
            tr.appendChild(td);
        }
        //추가 데이터 내용.
        var td = document.createElement('td');
        var btn = document.createElement('button');
        btn.textContent = '복사';
        btn.onclick = clickFnc;
        td.appendChild(btn); //td.innerHTML= '<button onclick="clickFnc(event)">상세보기</button>'; 
        tr.appendChild(td); //버튼 태그 사용시 textContent는 텍스트로 나옴


        tbody.appendChild(tr);
    }

    return tbody;
}


// 타이틀 부분
function makeHead() {
    var thead = document.createElement('thead');
    var tr = document.createElement('tr');
    //추가 타이틀 (체크박스)
    var th = document.createElement('th');
    th.textContent = '선택';
    tr.appendChild(th);
    for (var field in fields) {
        var th = document.createElement('th');
        th.textContent = fields[field];
        tr.appendChild(th);
    }
    // 타이틀 추가내용.
    th = document.createElement('th');
    th.textContent = '버튼';
    tr.appendChild(th);
    thead.appendChild(tr);
    return thead; //타이틀 부분을 만듦
    //<thead><tr><th>sno</th><th>sname</th>....</th></tr></thead>
}