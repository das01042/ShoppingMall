var students = []; // {sno : 'S0001', sname:'홍길동',sphone : '010-1111' sbirth : '1999-01-01'}
        //생성자 함수.
        function Student(sno, sname, sphone, sbirth, sscore) {
            this.sno = sno;
            this.sname = sname;
            this.sphone = sphone;
            this.sbirth = sbirth;
            this.sscore = sscore;
        }

        students[0] = new Student('S0001', '홍길동', '010-1111', '1999-01-01', 65);
        students.push(new Student('S0002', '박문규', '010-2222', '1998-03-03', 73));
        //push : 배열 뒤에(순서에) 맞게 추가를 할때
        students.push(new Student('S0003', '김민수', '010-3333', '1997-04-05', 88));
        students.unshift(new Student('S0004', '황이현', '010-4444', '1993-07-05', 91));
        //unshift : 배열 앞쪽에 추가를 할때
        console.log(students);
        //(1:이벤트이름,2:함수)
        window.addEventListener('DOMContentLoaded', windowLoad);
        //addEventListener : 이벤트를 등록하는 가장 권장하는 방식

        function windowLoad() {


            var studentsOver70 = students.filter(item => item.score > 70);

            document.write('<ul>');
            //배열의 요소 갯수 만큼 반복 => for(var i=0;i<ary.length;i++){}, for(var obj of ary){}
            studentsOver70.forEach(item => {
                console.log(item);
                document.write('<li>' + item.sno + ', ' + item.sname + '</li>');

            });
            // 메소드의 매개값으로 함수가 들어오면 이 함수를 콜백함수라고 함
            document.write('<ul>');


            function forEachCallBackFnc(item, index, ary) {
                document.write('<li>' + item.sno + ', ' + item.sname + '</li>');

            }
        }