package com.yedam.common;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import emp.DAO;

class Employee {
	private int employeeId;
	private String firstName;
	private String lastName;
	private String email;
	private String phonNumber;
	private String hireDate;
	private String jobId;
	private int salary;
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + ", phonNumber=" + phonNumber + ", hireDate=" + hireDate + ", jobId=" + jobId + ", salary="
				+ salary + "]";
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhonNumber() {
		return phonNumber;
	}

	public void setPhonNumber(String phonNumber) {
		this.phonNumber = phonNumber;
	}

	public String getHireDate() {
		return hireDate;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	//생성자
	public Employee() {
		
	}
	
	public Employee(int employeeId, String firstName, String lastName, String email, String phonNumber, String hireDate,
			String jobId, int salary) {

		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phonNumber = phonNumber;
		this.hireDate = hireDate;
		this.jobId = jobId;
		this.salary = salary;
	}
}
public class EmpDAO extends DAO{
	
	public String getString (String name) {
		String something = "Hello , World "+name;
		return something;
	}
	//전체조회
	public List<Employee>getEmployees(){
		List<Employee> list = new ArrayList<>();
		String sql = "select *from empl_demo order by 1 desc";
		//1 db연결.
		connect();
		//쿼리결과 <=> stmt,psmt
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				Employee emp =new Employee(rs.getInt("employee_id")
						,rs.getString("first_name")
						,rs.getString("last_name")
						,rs.getString("email")
						,rs.getString("phone_number")
						,rs.getString("hire_date")
						,rs.getString("job_id")
						,rs.getInt("salary"));
				list.add(emp);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disconnect();
		}
		
		return list;
	}
	
	public void disconnect() {
		try {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	//연습용
	public List<String> getNames(){
		String [] names = {"홍길동","김민기","박정숙","최근영"};
		List<String>returnList = new ArrayList<>();
		for(String name : names) {
			returnList.add(name);
		}
		return returnList;
	}
	public Map<String, Integer> getScores(){
		String[] names = {"홍길동","김민기","박정숙","최근영"};
		Map<String,Integer> map = new HashMap<>();
		int score = 80;
		for(String name: names) {
			map.put(name, score++);
		}
		return map;
	}
}


